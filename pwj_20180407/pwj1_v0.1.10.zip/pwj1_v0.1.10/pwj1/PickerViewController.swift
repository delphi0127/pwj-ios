//
//  PickerViewController.swift
//  pwj1
//
//  Created by Apollo on 15/7/27.
//  Copyright (c) 2015年 Apollo. All rights reserved.
//

import UIKit
import CoreLocation
import AddressBook
import SystemConfiguration

class PickerViewController: UITableViewController, CLLocationManagerDelegate, UIPickerViewDelegate {
    var dataArr:Array<AnyObject> = []
    var dataArr_tmp:Array<AnyObject> = [] //sql查询的内部变量
//    var dataArr_key:Array<AnyObject> = []
//    var dataArr_dic:Dictionary = ["nil":"nil"]
//    var dataArr_tmp:Array<String> = []
//    var dataArr_tmp_dic:Dictionary = ["nil":"nil"]
//    var dataArr_tmp_key:String = "nil"
//    var dataArr_tmp_object:String = "nil"
    var cityflag:Int8!
    var city_count:Int32!       //pickerView城市的厂商count
    var city_count_loc:Int32!   ////locationManager的城市，周围厂商的count
    var cityflag_pickerCitiesData:Int8 = 0
    var picker2countyflag:String = "Empty"
    var dataOne_lat_lon:Array<AnyObject> = []
    var database:COpaquePointer = nil
    //location variable
    var pv_lon_from:CLLocationDegrees!
    var pv_lat_from:CLLocationDegrees!
    var province_PickerView:NSString!
    var prefecture_PickerView:NSString!
    var location2city:String = "定位中……"
    var picker2city:String!
    var locationManager: CLLocationManager!
    var currLocation: CLLocation!
    //picker var
    var pickerData : NSDictionary!          //保存全部数据
    var pickerProvincesData: NSArray!       //当前的省数据
    var pickerCitiesData : NSArray!         //当前的省下面的市数据
    
    let filePath:String = NSBundle.mainBundle().pathForResource("pwjcs", ofType: "db")!
    
    @IBOutlet weak var pkr: UIPickerView!   //picker
//    @IBOutlet weak var pkrLabel: UILabel!
    @IBOutlet var tLabel: UILabel!      //tableview cell1.label
    
    
    @IBAction func btn(sender: AnyObject) {
        let row1 = self.pkr.selectedRowInComponent(0)
        let row2 = self.pkr.selectedRowInComponent(1)
        
        //Swift1.1 -> Swift1.2修改点 start
        let selected1 = self.pickerProvincesData[row1] as! String//as改为as!
//        println(self.pickerCitiesData)
        if cityflag_pickerCitiesData  == 1 {
        let selected2 = self.pickerCitiesData[row2] as! String  //as改为as!
        _ = String(format: "%@，%@", selected1,selected2)//NSString改为String
        //Swift1.1 -> Swift1.2修改点 end
        _ = storyboard?.instantiateViewControllerWithIdentifier("detailviewcontroller") as! DetailViewController
//        let detailviewcontroller = segue.destinationViewController as! DetailViewController//as改为as!
//        let indexPath = self.tableView.indexPathForSelectedRow() as NSIndexPath?
//        let selectedIndex = indexPath!.row
//        var cell_title: String = dataArr[selectedIndex] as! String
        
//        self.pkrLabel.text = Pickertitle
        picker2city = selected2
        picker2countyflag = "Empty"    //全局标示flag在置1前，都需要函数内先置0,"Empty"
            
        //若选取城市为北京等，标picker2countyflag为selected1，sql查询county_level_city
        if selected1 == "北京" || selected1 == "上海" || selected1 == "天津" || selected1 == "重庆"{
            picker2countyflag = selected1
//            detailviewcontroller.picker2countyflag = 1   // detailviewcontroller.picker2countyflag赋值无效，只在prepareforsegue赋值有效
        }
        //若选取城市为全部，标picker2city为"prefecture_level_city"，sql查询prefecture_level_city=prefecture_level_city(查询全部)
        if selected1 == "中国" {
            picker2city = "prefecture_level_city"
        }
//        detailviewcontroller.loc_city = picker2city   // detailviewcontroller.loc_city只在prepareforsegue赋值有效
        self.refreshData()      //位于传变量语句后，再调用prepareForSegue，传递detailviewcontroller.loc_city的值
        
//        self.tableView.selectRowAtIndexPath(indexPath, animated: true, scrollPosition: UITableViewScrollPosition)
//        presentViewController(detailviewcontroller, animated: true, completion: nil)
        //        println(selected2)
        } else {
        picker2city = ""
        self.refreshData()      //位于传变量语句后，再调用prepareForSegue，传递detailviewcontroller.loc_city的值
        }
    }
    //定位管理器
//    let locationManager:CLLocationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
//        let filePath:String = NSBundle.mainBundle().pathForResource("pwjcs", ofType: "db")!
        var seletedProvince:String = "nil"
//        var cell1:UITableViewCell! = self.tableView.dequeueReusableCellWithIdentifier("cell1") as? UITableViewCell
        
//        if (cell1 == nil){
//            cell1 = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: "cell1")
//        }
        self.locationManager = CLLocationManager()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.locationManager.delegate = self
        
        //数据查询
//        if sqlite3_open(filePath,&database) == SQLITE_OK {
//            //if sqlite3_open(databasePath,&database) == SQLITE_OK {
//            let sql_PickerView = "SELECT prov,prefec FROM prov_prefec;"
//            recordSet(sql_PickerView)
//            dataArr = dataArr_tmp     //保证数组不为数据库查询而变
//            dataArr_tmp = []
//        }else {
//            sqlite3_close(database)
//            println("open database failed")
//        }
//        if sqlite3_open(filePath,&database) == SQLITE_OK {
//            //if sqlite3_open(databasePath,&database) == SQLITE_OK {
//            let sql_PickerView = "SELECT prov FROM prov_prefec;"
//            recordSet(sql_PickerView)
//            dataArr_key = dataArr_tmp     //保证数组不为数据库查询而变
//            dataArr_tmp = []
//        }else {
//            sqlite3_close(database)
//            println("open database failed")
//        }
        
        //设置定位服务管理器代理
        locationManager.delegate = self
        //设置定位进度
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        //更新距离
        locationManager.distanceFilter = 100
        //发送授权申请
        locationManager.requestAlwaysAuthorization()
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
//        println(location2city)
//        cell1.textLabel!.text = location2city as String   //不能显示location2city的内容
        
        tLabel.text = "定位中……"    //定位数据没更新，不能设置label
//        pkr.selectRow(6, inComponent: 0, animated: true)
//        pkr.selectRow(3, inComponent: 1, animated: true)
//        pkrLabel.text = "请选取销售城市……"
        
        //PickerView的设置
        let plistPath = NSBundle.mainBundle().pathForResource("provinces_cities", ofType: "plist")
        //获取属性列表文件中的全部数据
        let dict = NSDictionary(contentsOfFile: plistPath!)
        
        self.pickerData = dict
//        pickerData = NSDictionary(objects: dataArr, forKeys: dataArr_key)
//        println(dataArr)
//        println(pickerData)
        //省份名数据
        pickerProvincesData = self.pickerData.allKeys
        
        //默认取出第一个省的所有市的数据
        //Swift1.1 -> Swift1.2修改点 start
        seletedProvince = self.pickerProvincesData[31] as! String//as NSString改为as! String
        pickerCitiesData = self.pickerData[seletedProvince] as! NSArray//as改为as!
        //Swift1.1 -> Swift1.2修改点 end
//        self.pkr.dataSource = self
        self.pkr.delegate = self
        self.pkr.selectRow(31, inComponent: 0, animated: true)     //需要在pickerview.delegate的基础上运行
//        seletedProvince = self.pickerProvincesData[29] as! String//as NSString改为as! String
//        pickerCitiesData = self.pickerData[seletedProvince] as! NSArray//as改为as!
        self.pkr.reloadComponent(0)
        self.pkr.selectRow(0, inComponent: 1, animated: true)
        
        //解决首次加载直接点“确定”不调用pickerView(pkr, didSelectRow: 31, inComponent: 0)，和初始pickerview数据无效
        self.pickerView(pkr, didSelectRow: 31, inComponent: 0)
        
        self.title = "抛丸机销售助手 v0.1"
    }

    //协议UIPickerViewDataSource方法
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
       	if (component == 0) {//省份个数
            return self.pickerProvincesData.count
           } else {//市的个数
            return self.pickerCitiesData.count
        }
    }
    
    //实现协议UIPickerViewDelegate方法
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        //Swift1.1 -> Swift1.2修改点 start
       	if (component == 0) {//选择省份名
            return self.pickerProvincesData[row] as? String//as改为as!
           } else {//选择市名
            return self.pickerCitiesData[row] as? String//as改为as!
        }
        //Swift1.1 -> Swift1.2修改点 end
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if (component == 0) {
            //Swift1.1 -> Swift1.2修改点 start
            let seletedProvince = self.pickerProvincesData[row] as! String//as改为as!
            var pickerCitiesData_tmp:Array<AnyObject> = []
            
            self.pickerCitiesData = self.pickerData[seletedProvince] as! NSArray//as改为as!
//            println(self.pickerCitiesData[0])
            //输出"全国"的厂商量
            if self.pickerCitiesData[0] as! String == "全国" {
                var pickerProvincesData_tmp:Array<AnyObject> = []
                
                if sqlite3_open(filePath,&database) == SQLITE_OK {
                    cityflag = 0   //使用前，函数内置为0
                    city_count = 0 //计城市的厂商数量
                    let sql_tableView = "SELECT ID,companyname FROM pwj_user;"
                    recordSet(sql_tableView)
                }else {
                    sqlite3_close(database)
                    print("open database failed")
                }
                
                pickerProvincesData_tmp.append("全国 （\(city_count)）")
                self.pickerCitiesData = pickerProvincesData_tmp
//                println(self.pickerCitiesData[0])
            }
            
            if seletedProvince != "中国" {
            //Swift1.1 -> Swift1.2修改点 end
//            println(pickerCitiesData_tmp)
            //检查pickerCitiesData的项在数据pwjcs.db能不能查询到
            cityflag_pickerCitiesData = 0
            for every_city in pickerCitiesData {
//                let filePath:String = NSBundle.mainBundle().pathForResource("pwjcs", ofType: "db")!
                
                dataArr_tmp = []
                if sqlite3_open(filePath,&database) == SQLITE_OK {
                    //if sqlite3_open(databasePath,&database) == SQLITE_OK {
                    //            println(loc_city)
                    cityflag = 0   //使用前，函数内置为0
                    city_count = 0 //计城市的厂商数量
                    
                    //北京需要seletedProvince查询
                    if seletedProvince  == "北京" || seletedProvince  == "上海" || seletedProvince  == "天津" || seletedProvince  == "重庆"{
                        let sql_tableView = "SELECT ID,companyname FROM pwj_user WHERE prefecture_level_city = '\(seletedProvince)' AND county_level_city = '\(every_city)';"
                        recordSet(sql_tableView)
                    } else {
                        let sql_tableView = "SELECT ID,companyname FROM pwj_user WHERE prefecture_level_city = '\(every_city)';"
                        recordSet(sql_tableView)
                    }
//                                println(loc_city)
                    dataArr = dataArr_tmp    //protect tableview stable
                }else {
                    sqlite3_close(database)
                    print("open database failed")
                }
                if cityflag == 1 {
                    pickerCitiesData_tmp.append("\(every_city) （\(city_count)）")
//                    println("\(every_city)(\(city_count))")
                    cityflag_pickerCitiesData = 1      // pickerCitiesData_tmp不为空，cityflag_pickerCitiesData置1
                }
            }
            pickerCitiesData = pickerCitiesData_tmp
//            println(pickerCitiesData)
            } else {                                  // seletedProvince为全部，cityflag_pickerCitiesData置1
                cityflag_pickerCitiesData = 1
            }
            
            if cityflag_pickerCitiesData != 1 {
                pickerCitiesData_tmp.append("无")     // seletedProvince的pickerCitiesData为nil，pickerCitiesData显示"无"
                pickerCitiesData = pickerCitiesData_tmp
            }
            self.pkr.reloadComponent(1)
        }
    }
    
    //获取设备是否允许使用定位服务
    func locationManager(manager: CLLocationManager,
        didChangeAuthorizationStatus status: CLAuthorizationStatus) {
            if status == CLAuthorizationStatus.NotDetermined || status == CLAuthorizationStatus.Denied{
                
            }else{
                //允许使用定位服务的话，开启定位服务更新
                locationManager.startUpdatingLocation()
                print("定位开始P1")
                
                //关闭定位
                //locationManager.stopUpdatingLocation()
            }
    }
    
    //定位改变执行，可以得到新位置、旧位置
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        //获取最新的坐标
//        var currLocation = locations.last!
        //swift2 ： locationManager.stopUpdatingLocation() // Stop Location Manager - keep here to run just once
        let geocoder:CLGeocoder = CLGeocoder()
//        var net:Bool = 0
//        SCNetworkReachabilityGetFlags("http://www.baidu.com", net)  //联网status:怎么用？
////        if (currLocation.horizontalAccuracy > 0) {
////            self.locationManager.stopUpdatingLocation()
////        }
////        var city_str:String = "联网失败"
////        var geocoder_flag:Int8 = 0 //标记geocoder.reverseGeocodeLocation查询是否执行，tLabel.text可以显示定位
//        if net == 0 {       //没有网络连接
//            tLabel.text = "请检查网络连接……"
//        }
        
        let currLocation = locations[locations.count - 1] as CLLocation//as改为as!
        //presentViewController(vc, animated: true, completion: nil) could pass the var vc.lat and  vc.lon
        //        var vc = storyboard?.instantiateViewControllerWithIdentifier("UserContent") as! ViewController_content
        //获取经度
//        println("经度：\(currLocation.coordinate.longitude),纬度：\(currLocation.coordinate.latitude)")
        pv_lon_from = currLocation.coordinate.longitude
        pv_lat_from = currLocation.coordinate.latitude
        self.currLocation = currLocation
        print("经度：\(pv_lon_from),纬度：\(pv_lat_from)")
        
        //查询地理信息
        geocoder.reverseGeocodeLocation(self.currLocation, completionHandler: { (placemarks, error) -> Void in
//            if placemarks != nil &&  placemarks!.count  > 0 {
                //Swift1.1 -> Swift1.2修改点 start
            if let validPlacemark = placemarks?[0] {
                let placemark:CLPlacemark = validPlacemark as CLPlacemark
//                let placemark = placemarks[0] as CLPlacemark   //as改为as!
                let addressDictionary = placemark.addressDictionary as! NSDictionary //.addressDictionary as NSDictionary
//                let filePath:String = NSBundle.mainBundle().pathForResource("pwjcs", ofType: "db")!

                var state:NSString = addressDictionary.objectForKey(kABPersonAddressStateKey) as! NSString     //as改为as!,NSString改为String
                var city:NSString = addressDictionary.objectForKey(kABPersonAddressCityKey) as! NSString   //as改为as!,NSString改为String
                state = state.substringToIndex(state.length - 1) as String   //去“省/市”字
                city = city.substringToIndex(city.length-1) as String
//                var state_str:String = state.substringToIndex(state.length - 1) as String   //去“省/市”字
//                var city_str:String = city.substringToIndex(city.length-1) as String
    
                if state == "北京" || state == "上海" || state == "天津" || state == "重庆" {
                    city = state
                }
                print("\(state),\(city)")    //省，市
                self.location2city = city as String
//                println(self.location2city)
//                self.picker2city = self.location2city
//                println(self.location2city)
//                self.tLabel.text = self.location2city
                
                //locationManager的城市周围厂商的count
                if sqlite3_open(self.filePath,&self.database) == SQLITE_OK {
                    //if sqlite3_open(databasePath,&database) == SQLITE_OK {
                    //            println(loc_city)
//                    cityflag = 0   //使用前，函数内置为0
                    self.city_count_loc = 0 //计定位方式的城市的厂商数量
                    
                    //北京等查询相同
                    let sql_tableView = "SELECT ID,companyname FROM pwj_user WHERE prefecture_level_city = '\(city)';"
                    self.recordSet(sql_tableView)
                    
//                                println(loc_city)
//                    dataArr = dataArr_tmp    //protect tableview stable
                }else {
                    sqlite3_close(self.database)
                    print("open database failed")
                }
                
                self.tLabel.text = "\(addressDictionary.objectForKey(kABPersonAddressStateKey)!),\(addressDictionary.objectForKey(kABPersonAddressCityKey)!)  潜在客户（\(self.city_count_loc)）"
                //                //                println(state.length)
                //                self.location2city = city_str
                //                //                println(state)  //省
                //                println(self.location2city)
                
                //                if self.location2city == "null" {
                //                    self.location2city == "定位无效"
                //                }
                //                self.txtView.text = String(format: "%@ \n%@ \n%@", state, address,city)
                //Swift1.1 -> Swift1.2修改点 end
            }
        })
//        self.location2city = city_str
        //                println(state)  //省
//        println(self.location2city)     //不能println
//        println(geocoder_flag)
 
//        tLabel.text = location2city     //此位置的tLabel.text先于geocoder.reverseGeocodeLocation运行，无效值

        //        println(vc_lat_from)
        //         //获取海拔
        //        label3.text = "海拔：\(currLocation.altitude)"
        //        //获取水平精度
        //        label4.text = "水平精度：\(currLocation.horizontalAccuracy)"
        //        //获取垂直精度
        //        label5.text = "垂直精度：\(currLocation.verticalAccuracy)"
        //        //获取方向
        //        label6.text = "方向：\(currLocation.course)"
        //        //获取速度
        //        label7.text = "速度：\(currLocation.speed)"
    }
    
    //MARK: --Core Location委托方法用于实现位置的更新
//    func locationManager(manager: CLLocationManager!, didUpdateLocations locations: [AnyObject]!) {
//        
//        //Swift1.1 -> Swift1.2修改点 start
//        self.currLocation = locations[locations.count - 1] as! CLLocation //as改为as!
////        self.txtLat.text = String(format:"%3.5f", currLocation.coordinate.latitude)//NSString改为String
////        self.txtLng.text = String(format:"%3.5f", currLocation.coordinate.longitude)//NSString改为String
////        self.txtAlt.text = String(format:"%3.5f", currLocation.altitude)//NSString改为String
//        //Swift1.1 -> Swift1.2修改点 end
//        
//        NSLog("%3.5f",  currLocation.coordinate.latitude)
//        
//    }
    
    func recordSet(sql: String) {
        var stmt:COpaquePointer = nil    // 准备语句
        city_count = 0
        city_count_loc = 0
        /**
        1. 数据库句柄
        2. SQL 的 C 语言的字符串
        3. SQL 的 C 语言的字符串长度 strlen，-1 会自动计算
        4. stmt 的指针
        5. 通常传入 nil
        */
        if sqlite3_prepare_v2(database, sql.cStringUsingEncoding(NSUTF8StringEncoding)!, -1, &stmt, nil) == SQLITE_OK{
            //dataArr = context. stmt
            // 单步获取SQL执行的结果 -> sqlite3_setup 对应一条记录
//            city_count = SQLITE_ROW
            while sqlite3_step(stmt) == SQLITE_ROW {
                // 获取每一条记录的数据
                city_count = city_count + 1     //计pickerView的城市的厂商数量
                city_count_loc = city_count_loc + 1 //计location的城市的厂商数量
                recordData(stmt)
            }
        }
    }
    
    ///  获取每一条数据的记录
    ///
    ///  - parameter stmt: prepared_statement 对象
    func recordData(stmt:COpaquePointer) {
        // 获取到记录
        let count = sqlite3_column_count(stmt)
        var sqlite_int:Int64 = 0
        var sqlite_double:Double = 0.000000
        var sqlite_text:NSString = " "
        
//        dataArr_tmp = []
        //        println("获取到记录，共有\(count)列 ")
        // 遍历每一列的数据
        for i in 0..<count {
            let type = sqlite3_column_type(stmt, i)
            //            sqlite_int = 0
            //            sqlite_text = "none"
            cityflag = 1
            // 根据字段的类型，提取对应列的值
            switch type {
            case SQLITE_INTEGER:
                sqlite_int = sqlite3_column_int64(stmt, i)
                //println(sqlite_int)
                //                println("整数 \(sqlite3_column_int64(stmt, i))")
            case SQLITE_FLOAT:
                sqlite_double = sqlite3_column_double(stmt, i)
                //println(sqlite_double)
                //                println("小数 \(sqlite3_column_double(stmt, i))")
            case SQLITE_NULL:
                _ = NSNull()
                //println(sqlite_nil)
                //                println("空 \(NSNull())")
            case SQLITE_TEXT:
                let chars = UnsafePointer<CChar>(sqlite3_column_text(stmt, i))
                let str = String(CString: chars, encoding: NSUTF8StringEncoding)!
                
                sqlite_text = str
                //                println("字符串 \(str)")
//            case let type:     //also ok
            default:
                print("不支持的类型 \(type)")
            }
            //适用于获取每一条记录的多列数据
//            dataOne.append(sqlite_text)
//            dataOne_lat_lon.append(sqlite_double)
            //获取每一条记录的prov,prefec,字典dic
//            dataArr_tmp.append(sqlite_text as String)
            //            println("sqlite_double=\(sqlite_double)")
        }
        //适用于获取多条记录的同一列数据
//        dataArr_tmp_dic[dataArr_tmp[0]] = dataArr_tmp[1]
        //dataArr += [sqlite_int,sqlite_text]
//        dataArr.append(sqlite_text)
        //        println("\(sqlite_int)|\(sqlite_text)")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func refreshData() {
        //var f = NSFetchRequest(entityName: "pwjcs")
        //dataArr = context.executeFetchRequest(f, error: nil)!
        //dataArr = sqlite3_open("/Users/Apollo/Desktop/pwj/pwjcs.db",&database)
        tableView.reloadData()
    }
    
//    //实现表视图数据源方法,不能使用的
//    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
//        
//        let cellIdentifier = "cell1"
//        var cell1:UITableViewCell! = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath:indexPath) as? UITableViewCell
//        
//        if (cell1 == nil) {
//            cell1 = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: cellIdentifier)
//        }
////        let row = indexPath.row
//        //Swift1.1 -> Swift1.2修改点 start
//        cell1.textLabel?.text = location2city as? String//as改为as?,NSString改为String
//        //Swift1.1 -> Swift1.2修改点 end
//        return cell1
//    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {     //只在press时运行
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
        let detailviewcontroller = segue.destinationViewController as! DetailViewController//as改为as!
        if (segue.identifier == "ShowLocation") {
            //Swift1.1 -> Swift1.2修改点 start
//            let detailviewcontroller = segue.destinationViewController as! DetailViewController//as改为as!
            
            detailviewcontroller.city = location2city          //不需使用picker2countyflag，不能定位北京等城市的区
//            println(location2city)
            
//            segue.destinationViewController.
//            println(detailviewcontroller.loc_city)
//            let indexPath = self.tableView.indexPathForSelectedRow() as NSIndexPath?
//            let selectedIndex = indexPath!.row
//            
//            let selectName = self.listData[selectedIndex] as! String
//            detailviewcontroller.listData = self.dictData[selectName] as! NSArray//as改为as!
//            detailviewcontroller.title = selectName
        }
        if (segue.identifier == "ShowPicker") {
            //Swift1.1 -> Swift1.2修改点 start
//            let detailviewcontroller = segue.destinationViewController as! DetailViewController//as改为as!
//            let indexPath = self.tableView.indexPathForSelectedRow() as NSIndexPath?
//            let selectedIndex = indexPath!.row
//            
            detailviewcontroller.picker2countyflag = picker2countyflag //和定位得到的不同，定位不能得到北京等的“区”，不需使用这个flag
            detailviewcontroller.city = picker2city
//            println("111,\(detailviewcontroller.loc_city)")
//            let selectName = self.listData[selectedIndex] as! String
//            detailviewcontroller.listData = self.dictData[selectName] as! NSArray//as改为as!
//            detailviewcontroller.title = selectName
        }
    }
    
    // MARK: - Table view data source

    /*
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath) as! UITableViewCell

         Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return NO if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return NO if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

}
