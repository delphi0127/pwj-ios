//
//  Use this file to import your target's public headers that you would like to expose to Swift.
//

#import <sqlite3.h>
#import <UIKit/UIKit.h>
//#import <BaiduMapAPI/BMapKit.h>//引入所有的头文件
//#import <BaiduMapAPI/BMKMapView.h>//只引入所需的单个头文件
//#import "BMKView.h"

//@interface BaiduMapApiDemoAppDelegate : NSObject <UIApplicationDelegate> {
//    UIWindow *window;
//    UINavigationController *navigationController;
//    BMKMapManager* _mapManager;
//}

