//
//  TableViewController.swift
//  pwj1
//
//  Created by Apollo on 15/5/29.
//  Copyright (c) 2015年 Apollo. All rights reserved.
//

import UIKit
import CoreData
import CoreLocation

class DetailViewController: UITableViewController, CLLocationManagerDelegate, UISearchBarDelegate {

    //var dataArr:Array<NSString> = []
    //var context:NSManagedObjectContext!
    var dataArr:Array<AnyObject> = []
    var dataArr_tmp:Array<AnyObject> = [] //sql查询的内部变量
    var dataOne:Array<AnyObject> = []
    var dataOne_lat_lon:Array<AnyObject> = []
    var database:COpaquePointer = nil
    var dv_lon_from:CLLocationDegrees!
    var dv_lat_from:CLLocationDegrees!
    var province_detailView:NSString!
    var prefecture_detailView:NSString!
    var city:NSString!
    var picker2countyflag:String =  "Empty"  //检查是否为pickerview的4城市，"Empty"使定位的city可以在initSQL运行
    //定位管理器
    let locationManager:CLLocationManager = CLLocationManager()
    
    @IBOutlet weak var searchBar: UISearchBar!
    var listTerms : NSArray!
    var listFilterTerms : NSMutableArray!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        //context = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext
//        refreshData()
//    }
        //将pwjcs数据库文件的路径 读取
//        let dirPaths = NSSearchPathForDirectoriesInDomains(.DocumentDirectory,.UserDomainMask, true)
//        let docsDir = dirPaths[0] as! String
//        var databasePath = docsDir.stringByAppendingPathComponent("pwjcs.db")
//        var filePath:String = NSBundle.mainBundle().pathForResource("pwjcs", ofType: "db")!
        
        //设置定位服务管理器代理
        locationManager.delegate = self
        //设置定位进度
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        //更新距离
        locationManager.distanceFilter = 100
        //发送授权申请
        locationManager.requestAlwaysAuthorization()
        
        self.title = "厂商列表"
        
        //初始化读取数据
        self.initSql()
        
        //searchbar
        //设置搜索栏委托对象为当前视图控制器
        self.searchBar.delegate = self
//        println(self.dataArr)
        self.listTerms = NSArray(array: dataArr) //dataArr as NSArray<String>
//        println(self.listTerms)      //数据类型print
        self.filterContentForSearchText("", scope:-1)   //初始查询全部数据
    }
    
    //获取设备是否允许使用定位服务
    func locationManager(manager: CLLocationManager,
        didChangeAuthorizationStatus status: CLAuthorizationStatus) {
            if status == CLAuthorizationStatus.NotDetermined || status == CLAuthorizationStatus.Denied{
                
            }else{
                //允许使用定位服务的话，开启定位服务更新
                locationManager.startUpdatingLocation()
                print("定位开始")
                
                //关闭定位
                //locationManager.stopUpdatingLocation()
            }
    }
    
    //定位改变执行，可以得到新位置、旧位置
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        //获取最新的坐标
        let currLocation:CLLocation = locations.last! 
        //presentViewController(vc, animated: true, completion: nil) could pass the var vc.lat and  vc.lon
//        var vc = storyboard?.instantiateViewControllerWithIdentifier("UserContent") as! ViewController_content
        //获取经度
        print("经度：\(currLocation.coordinate.longitude),纬度：\(currLocation.coordinate.latitude)")
        dv_lon_from = currLocation.coordinate.longitude
        dv_lat_from = currLocation.coordinate.latitude
//        println(vc_lat_from)
        //         //获取海拔
        //        label3.text = "海拔：\(currLocation.altitude)"
        //        //获取水平精度
        //        label4.text = "水平精度：\(currLocation.horizontalAccuracy)"
        //        //获取垂直精度
        //        label5.text = "垂直精度：\(currLocation.verticalAccuracy)"
        //        //获取方向
        //        label6.text = "方向：\(currLocation.course)"
        //        //获取速度
        //        label7.text = "速度：\(currLocation.speed)"
    }

    /// 实现 UISearchBarDelegate 协议方法
    //  获得焦点，成为第一响应者
    func searchBarShouldBeginEditing(searchBar: UISearchBar) -> Bool {
        self.searchBar.showsScopeBar = true
        self.searchBar.sizeToFit()
        return true
    }
    
    //点击键盘上的搜索按钮
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        self.searchBar.showsScopeBar = false
        self.searchBar.resignFirstResponder()
        self.searchBar.sizeToFit()
    }
    //点击搜索栏取消按钮
    func searchBarCancelButtonClicked(searchBar : UISearchBar) {
        //查询所有
        self.initSql()
        self.filterContentForSearchText("", scope:-1)
        self.searchBar.showsScopeBar = false
        self.searchBar.resignFirstResponder()
        self.searchBar.sizeToFit()
    }
    
    //当文本内容发生改变时候调用
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        self.filterContentForSearchText(searchText, scope:self.searchBar.selectedScopeButtonIndex)
        self.tableView.reloadData()
    }
    
    //当搜索范围选择发生变化时候调用
    func searchBar(searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        self.filterContentForSearchText(self.searchBar.text!, scope:selectedScope)
        self.tableView.reloadData()
    }
    
    //过滤结果集方法
    func filterContentForSearchText(searchText: NSString, scope: Int) {
        if(searchText.length == 0) {
            //查询所有
            self.listFilterTerms = NSMutableArray(array:self.listTerms)
            dataArr = self.listFilterTerms as Array<AnyObject>    //利用dataArr，将检索初始数据在tableviewcell上输出
            return
        }
        var tempArray : NSArray!
        
        if (scope != -1) {      //查询
            let scopePredicate = NSPredicate(format:"SELF contains[c] %@", searchText)
            //Swift1.1 -> Swift1.2修改点 start
            tempArray = self.listTerms.filteredArrayUsingPredicate(scopePredicate)//删除!
            //Swift1.1 -> Swift1.2修改点 end
            self.listFilterTerms = NSMutableArray(array: tempArray)
//            println(self.listFilterTerms)
            dataArr = self.listFilterTerms as Array<AnyObject>    //利用dataArr，将检索得到的数据在tableviewcell上输出
        } else {                //查询所有
            self.listFilterTerms = NSMutableArray(array: self.listTerms)
            dataArr = self.listFilterTerms as Array<AnyObject>    //利用dataArr，将检索初始数据在tableviewcell上输出
        }
    }
    
    func initSql() {             //区域数据的初始化
        let filePath:String = NSBundle.mainBundle().pathForResource("pwjcs", ofType: "db")!
        if sqlite3_open(filePath,&database) == SQLITE_OK {
            //if sqlite3_open(databasePath,&database) == SQLITE_OK {
            let trimmingSet = NSCharacterSet(charactersInString: "（）() 0123456789")
            
            city = city.stringByTrimmingCharactersInSet(trimmingSet)   //删除"city(city_count)"的"(city_count)"
//            println(city)
            //北京需要province查询
            if city != nil {
                if picker2countyflag != "Empty" {
                    let sql_tableView = "SELECT ID,companyname FROM pwj_user WHERE prefecture_level_city = '\(picker2countyflag)' AND county_level_city = '\(city)';"
                    recordSet(sql_tableView)
                } else if city == "prefecture_level_city" {
                    let sql_tableView = "SELECT ID,companyname FROM pwj_user WHERE prefecture_level_city = \(city);"
                    recordSet(sql_tableView)
                }else {
                    let sql_tableView = "SELECT ID,companyname FROM pwj_user WHERE prefecture_level_city = '\(city)';"
                    recordSet(sql_tableView)
                }
            }
            //            println(loc_city)
            dataArr = dataArr_tmp    //protect tableview stable
        }else {
            sqlite3_close(database)
            print("open database failed")
        }
    }
    
    func recordSet(sql: String) {
        var stmt:COpaquePointer = nil    // 准备语句
        /**
        1. 数据库句柄
        2. SQL 的 C 语言的字符串
        3. SQL 的 C 语言的字符串长度 strlen，-1 会自动计算
        4. stmt 的指针
        5. 通常传入 nil
        */
        if sqlite3_prepare_v2(database, sql.cStringUsingEncoding(NSUTF8StringEncoding)!, -1, &stmt, nil) == SQLITE_OK{
            //dataArr = context. stmt
            // 单步获取SQL执行的结果 -> sqlite3_setup 对应一条记录
            while sqlite3_step(stmt) == SQLITE_ROW {
                // 获取每一条记录的数据
                recordData(stmt)
            }
        }
    }
    
    ///  获取每一条数据的记录
    ///
    ///  - parameter stmt: prepared_statement 对象
    func recordData(stmt:COpaquePointer) {
        // 获取到记录
        let count = sqlite3_column_count(stmt)
        var sqlite_int:Int64 = 0
        var sqlite_double:Double = 0.000000
        var sqlite_text:NSString = " "
//        println("获取到记录，共有\(count)列 ")
        // 遍历每一列的数据
        for i in 0..<count {
            let type = sqlite3_column_type(stmt, i)
//            sqlite_int = 0
//            sqlite_text = "none"
            // 根据字段的类型，提取对应列的值
            switch type {
            case SQLITE_INTEGER:
                sqlite_int = sqlite3_column_int64(stmt, i)
                //println(sqlite_int)
//                println("整数 \(sqlite3_column_int64(stmt, i))")
            case SQLITE_FLOAT:
                sqlite_double = sqlite3_column_double(stmt, i)
                //println(sqlite_double)
//                println("小数 \(sqlite3_column_double(stmt, i))")
            case SQLITE_NULL:
                _ = NSNull()
                //println(sqlite_nil)
//                println("空 \(NSNull())")
            case SQLITE_TEXT:
                let chars = UnsafePointer<CChar>(sqlite3_column_text(stmt, i))
                let str = String(CString: chars, encoding: NSUTF8StringEncoding)!
                sqlite_text = str
//                println("字符串 \(str)")
            case let type:
                print("不支持的类型 \(type)")
            }
            //适用于获取每一条记录的多列数据
            dataOne.append(sqlite_text)
            dataOne_lat_lon.append(sqlite_double)
//            println("sqlite_double=\(sqlite_double)")
        }
        //适用于获取多条记录的同一列数据
        //dataArr += [sqlite_int,sqlite_text]
        dataArr_tmp.append(sqlite_text)
//        println("\(sqlite_int)|\(sqlite_text)")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//////////////////////////////////////////////////////////////////////////////////////////////////////////
    //coredata use
//////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    func refreshData() {
        //var f = NSFetchRequest(entityName: "pwjcs")
        //dataArr = context.executeFetchRequest(f, error: nil)!
        //dataArr = sqlite3_open("/Users/Apollo/Desktop/pwj/pwjcs.db",&database)
        tableView.reloadData()
    }
//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning()
//        // Dispose of any resources that can be recreated.
//    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete method implementation.
        // Return the number of rows in the section.
        //println(dataArr.count)
        return dataArr.count
    }

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath) 

        // Configure the cell...
        let name:AnyObject? = dataArr[indexPath.row].self
        //var age:AnyObject? = dataArr[indexPath.row].valueForKey("age")
//        var label = cell.viewWithTag(2) as! UILabel     //another method to show label.text        
//        label.text = "\(name!)"
        cell.textLabel?.text = "\(name!)"
        return cell
    }
    
//    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
//        //var data = dataArr[indexPath.row] as! NSManagedObject
//        var data_title: String = dataArr[indexPath.row] as! String
//        var vc = storyboard?.instantiateViewControllerWithIdentifier("UserContent") as! ViewController_content
//        var filePath:String = NSBundle.mainBundle().pathForResource("pwjcs", ofType: "db")!
//        var prov2city:String = "prefecture_level_city"
//        
//        if loc_city == "北京" || loc_city == "上海" || loc_city == "天津" || loc_city == "重庆" {   //不同的查询方式，北京需要按prov查询
//            prov2city = "province"
//        }
//        if sqlite3_open(filePath,&database) == SQLITE_OK {
//            //if sqlite3_open(databasePath,&database) == SQLITE_OK {
//            
//            let sql_cellView = "select companyname,liaisons,www,address,description,main_products_using_pwj,related_sailer,used_pwjs from pwj_user where \(prov2city) = '\(self.loc_city)' and companyname = '\(data_title)';"
//            println(sql_cellView)
//            let sql_cellPosition = "select latitude,longitude from pwj_user where \(prov2city) = '\(self.loc_city)' and companyname = '\(data_title)';"
////            println("sql_tableView=\(sql_cellView)")
//            dataOne = []   //clean the previous data
//            recordSet(sql_cellView)
//            dataOne_lat_lon = []    //clean the previous data
////            println("****************************")
//            recordSet(sql_cellPosition)
////            println("sql_tableView_21=\(sql_cellView)")
////            println("dataOne=\(dataOne)")
////            println("dataOne_lat_lon=\(dataOne_lat_lon)")
//        }else {
//            sqlite3_close(database)
////            println("open database failed")
//        }
//        
//        var dataText:NSString = "nil"
//        dataText = "公司名称：\(dataOne[0])\n"
//        dataText = "\(dataText)联系方式：\(dataOne[1])\n"
//        dataText = "\(dataText)网址：\(dataOne[2])\n"
//        dataText = "\(dataText)地址：\(dataOne[3])\n"
//        dataText = "\(dataText)公司介绍：\(dataOne[4])\n"
//        dataText = "\(dataText)主要使用抛丸机产品为：\(dataOne[5])\n"
//        dataText = "\(dataText)有关销售人员：\(dataOne[6])\n"
//        dataText = "\(dataText)已有抛丸机销售：\(dataOne[7])\n"
////        println(dataText)
//        
//        vc.data = dataText
//        vc.lat_from = dv_lat_from      //current location from locationManager
//        vc.lon_from = dv_lon_from
//        vc.lat_to = dataOne_lat_lon[0] as! CLLocationDegrees
//        vc.lon_to = dataOne_lat_lon[1] as! CLLocationDegrees
//        presentViewController(vc, animated: true, completion: nil)
//    }

    override func viewWillAppear(animated: Bool) {
//        dataArr = []   //不能初始化了
        refreshData()
//        BMKMapView.viewWillAppear = self  // 此处记得不用的时候需要置nil，否则影响内存的释放
//        BMKMapView.delete()=nil           // 不用时，置nil 
    }
 
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {     //只在press时运行
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
        if (segue.identifier == "showDetail") {
            //Swift1.1 -> Swift1.2修改点 start
            let viewcontroller_content = segue.destinationViewController as! ViewController_content//as改为as!
            let indexPath = self.tableView.indexPathForSelectedRow as NSIndexPath?
            let selectedIndex = indexPath!.row
            let cell_title: String = dataArr[selectedIndex] as! String
//            var vc = storyboard?.instantiateViewControllerWithIdentifier("UserContent") as! ViewController_content
            let filePath:String = NSBundle.mainBundle().pathForResource("pwjcs", ofType: "db")!
            var prov2city:String = "prefecture_level_city"
            
//            if loc_city in "北京""上海" {
//            if loc_city == "北京" || loc_city == "上海" || loc_city == "天津" || loc_city == "重庆" {   //不同的查询方式，北京需要按prov查询
//                prov2city = "province"
//            }
            if picker2countyflag != "Empty" {
                prov2city = "county_level_city"
            }
            if sqlite3_open(filePath,&database) == SQLITE_OK {
                //if sqlite3_open(databasePath,&database) == SQLITE_OK {
                if city == "prefecture_level_city" {             //不list全部数据
                    let sql_cellView = "select companyname,liaisons,www,address,description,main_products_using_pwj,related_sailer,used_pwjs from pwj_user where \(prov2city) = \(self.city) and companyname = '\(cell_title)';"
                    //                println(sql_cellView)
                    let sql_cellPosition = "select latitude,longitude from pwj_user where \(prov2city) = \(self.city) and companyname = '\(cell_title)';"
                    
                    dataOne = []   //clean the previous data
                    recordSet(sql_cellView)
                    dataOne_lat_lon = []    //clean the previous data
                    //            println("****************************")
                    recordSet(sql_cellPosition)
                }else if picker2countyflag == "Empty" {
                    let sql_cellView = "select companyname,liaisons,www,address,description,main_products_using_pwj,related_sailer,used_pwjs from pwj_user where \(prov2city) = '\(self.city)' and companyname = '\(cell_title)';"
                    //                println(sql_cellView)
                    let sql_cellPosition = "select latitude,longitude from pwj_user where \(prov2city) = '\(self.city)' and companyname = '\(cell_title)';"
                    dataOne = []   //clean the previous data
                    recordSet(sql_cellView)
                    dataOne_lat_lon = []    //clean the previous data
                    //            println("****************************")
                    recordSet(sql_cellPosition)
                }else {
                    let sql_cellView = "select companyname,liaisons,www,address,description,main_products_using_pwj,related_sailer,used_pwjs from pwj_user where prefecture_level_city = '\(picker2countyflag)' AND  \(prov2city) = '\(self.city)' and companyname = '\(cell_title)';"
                    //                println(sql_cellView)
                    let sql_cellPosition = "select latitude,longitude from pwj_user where \(prov2city) = '\(self.city)' and companyname = '\(cell_title)';"
                    dataOne = []   //clean the previous data
                    recordSet(sql_cellView)
                    dataOne_lat_lon = []    //clean the previous data
                    //            println("****************************")
                    recordSet(sql_cellPosition)
                }
                //            println("sql_tableView=\(sql_cellView)")
                //            println("sql_tableView_21=\(sql_cellView)")
                //            println("dataOne=\(dataOne)")
                //            println("dataOne_lat_lon=\(dataOne_lat_lon)")
            }else {
                sqlite3_close(database)
                //            println("open database failed")
            }
            
            var dataText:NSString = "nil"
            
            for i in 0...7 {
//                println(dataOne[i])
                if dataOne[i] as! String == "null" {
                    dataOne[i]  = "无"
                }
                
            }
            
            dataText = "公司名称：\(dataOne[0])\n"
            dataText = "\(dataText)联系方式：\(dataOne[1])\n"
            dataText = "\(dataText)网址：\(dataOne[2])\n"
            dataText = "\(dataText)地址：\(dataOne[3])\n"
            dataText = "\(dataText)公司介绍：\(dataOne[4])\n"
            dataText = "\(dataText)主要使用抛丸机产品为：\(dataOne[5])\n"
            dataText = "\(dataText)有关销售人员：\(dataOne[6])\n"
            dataText = "\(dataText)已有抛丸机销售：\(dataOne[7])\n"
            //        println(dataText)
            
            viewcontroller_content.data = dataText
            viewcontroller_content.lat_from = dv_lat_from      //current location from locationManager
            viewcontroller_content.lon_from = dv_lon_from
            viewcontroller_content.lat_to = dataOne_lat_lon[0] as! CLLocationDegrees
            viewcontroller_content.lon_to = dataOne_lat_lon[1] as! CLLocationDegrees
            
            self.searchBar.resignFirstResponder()    //收起键盘
            //            println(detailviewcontroller.loc_city)
            //            let indexPath = self.tableView.indexPathForSelectedRow() as NSIndexPath?
            //            let selectedIndex = indexPath!.row
            //
            //            let selectName = self.listData[selectedIndex] as! String
            //            detailviewcontroller.listData = self.dictData[selectName] as! NSArray//as改为as!
            //            detailviewcontroller.title = selectName
        }
    }
//////////////////////////////////////////////////////////////////////////////////////////////////////////
    //为将tableview展示为section模式的code
//////////////////////////////////////////////////////////////////////////////////////////////////////////
    
//    func tableView(tableView: UITableView!, cellForRowAtIndexPath indexPath: NSIndexPath!) -> UITableViewCell! {
//        
//        var cell1 : AnyObject! = tableView.dequeueReusableCellWithIdentifier("cell1")
//        
//        var label = cell1.viewWithTag(Tag_cell_lable) as! UILabel
//        label.text = (data.allValues[indexPath.section] as! NSArray).objectAtIndex(indexPath.row) as! String
//        
//        return cell1 as! UITableViewCell
//    }
//    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
//        println("\((data.allValues[indexPath.section] as! NSArray).objectAtIndex(indexPath.row)) Clicked")
//    }
//    
//    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return (data.allValues[section] as! NSArray).count
//    }
//}

    
//////////////////////////////////////////////////////////////////////////////////////////////////////////
    //Xcode的auto代码
//////////////////////////////////////////////////////////////////////////////////////////////////////////
    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return NO if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return NO if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

}
