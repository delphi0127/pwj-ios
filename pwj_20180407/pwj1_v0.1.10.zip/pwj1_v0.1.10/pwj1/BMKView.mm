//
//  BMKView.mm
//  pwj1
//
//  Created by Apollo on 15/6/17.
//  Copyright (c) 2015年 Apollo. All rights reserved.
//
#import <UIKit/UIKit.h>
//#import <BaiduMapAPI/BMapKit.h>//引入所有的头文件
//#import <BaiduMapAPI/BMKMapView.h>//只引入所需的单个头文件
//#import <Foundation/Foundation.h>
//#import "BMKView.h"
//#import "AppDelegate.swift"

//@interface BaiduMapApiDemoAppDelegate : NSObject <UIApplicationDelegate> {
//        UIWindow *window;
//        UINavigationController *navigationController;
//        BMKMapManager* _mapManager;
//}
//@end

//@interface BMKView : NSObject <UIApplicationDelegate> {
//    UIWindow *window;
//    UINavigationController *navigationController;
//    BMKMapManager* _mapManager;
//}
//@end

//@implementation BMKView
//
//- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
//    // 要使用百度地图，请先启动BaiduMapManager
//    _mapManager = [[BMKMapManager alloc]init];
//    // 如果要关注网络及授权验证事件，请设定     generalDelegate参数
//    BOOL ret = [_mapManager start:@"NSpYTUQez4GIweuSTYZRFaf5"  generalDelegate:nil];
//    if (!ret) {
//        NSLog(@"manager start failed!");
//    }
//    // Add the navigation controller's view to the window and display.
////    [self.window addSubview:navigationController.view];
////    [self.window makeKeyAndVisible];
//    return YES;
//}
//
//
//- (void) viewDidLoad {
//    //[super viewDidLoad];
//    NSLog(@"test");
//    mapView = [[BMKMapView alloc]initWithFrame:CGRectMake(0, 0, 320, 480)];
//    //self.view = mapView;
//    [self addSubview:mapView];
//}
//
//- (void) viewWillAppear:(BOOL)animated
//{
//    [mapView viewWillAppear];
//    mapView.delegate = self; // 此处记得不用的时候需要置nil，否则影响内存的释放
//}
//- (void) viewWillDisappear:(BOOL)animated
//{
//    [mapView viewWillDisappear];
//    mapView.delegate = nil; // 不用时，置nil
//}
//
//@end

