//
//  BMKView.h
//  pwj1
//
//  Created by Apollo on 15/6/21.
//  Copyright (c) 2015年 Apollo. All rights reserved.
//

#ifndef pwj1_BMKView_h
#define pwj1_BMKView_h
#import <UIKit/UIKit.h>
#import <BaiduMapAPI/BMapKit.h>//引入所有的头文件
#import <BaiduMapAPI/BMKMapView.h>//只引入所需的单个头文件


//@interface BMKView : UIView <BMKMapViewDelegate> {
//        UIWindow *window;
//        UINavigationController *navigationController;
//        BMKMapManager* _mapManager;
//}
//@end

//@interface BMKView : UIViewController <BMKMapViewDelegate> {
//    IBOutlet BMKMapView* _mapView;//.xib里要有BMKMapView类用于初始化数据驱动
//    IBOutlet UITextField* _nativeEndLongitude;
//    IBOutlet UITextField* _nativeEndLatitude;
//    IBOutlet UITextField* _nativeEndName;
//    IBOutlet UITextField* _webStartLongitude;
//    IBOutlet UITextField* _webStartLatitude;
//    IBOutlet UITextField* _webStartName;
//    IBOutlet UITextField* _webEndLongitude;
//    IBOutlet UITextField* _webEndLatitude;
//    IBOutlet UITextField* _webEndName;
//}
//
//- (IBAction)nativeNavi;
//- (IBAction)webNavi;
//- (IBAction)textFiledReturnEditing:(id)sender;
//- (IBAction)textViewDidBeginEditing:(id)sender;
//@end

#endif
